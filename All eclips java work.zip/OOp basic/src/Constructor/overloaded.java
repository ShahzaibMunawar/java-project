package Constructor;

public class overloaded {
student portal=new student();

portal.assign("shahzaib","047","3.6");
portal.display();
}
class student{
	String Name;
	String rollno;
	String CGPA;
	
	void assign(String n , String r , String c){
		Name=n;
		rollno=r;
		CGPA=c;		
	}
	void display(){
		System.out.println("Name"+ Name );
		System.out.println("Rollno"+ rollno );
		System.out.println("CGPA"+ CGPA );
	}
}