package classs_inharitance;

public class tryme {

}
