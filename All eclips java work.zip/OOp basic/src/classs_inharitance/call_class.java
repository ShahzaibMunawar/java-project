package classs_inharitance;

public class call_class {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		atm Account = new atm();

		Account.drawMoney = 100;
		Account.addMoney = 25000;
		Account.total();

	}

}

class atm {

	double drawMoney;
	double addMoney;
	double Total;

	void total() {
		Total = addMoney - drawMoney;
		System.out.println("Total=" + Total);
	}

}