package gui;

public class lo_g {

}
