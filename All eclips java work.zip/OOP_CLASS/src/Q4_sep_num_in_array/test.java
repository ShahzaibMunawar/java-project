package Q4_sep_num_in_array;

public class test {
	public static void main(String[] args) {
		digit obj = new digit();

		obj.cheak();
		
		obj.show();
	}
}
