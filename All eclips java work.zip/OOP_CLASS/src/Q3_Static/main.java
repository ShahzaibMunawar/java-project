package Q3_Static;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		subclass obj1 = new subclass();
		subclass obj2 = new subclass();
		subclass obj3 = new subclass();
		subclass obj4 = new subclass();
		subclass obj5 = new subclass();
		subclass obj6 = new subclass();
		subclass obj7 = new subclass();
		subclass obj8 = new subclass();
		subclass obj9 = new subclass();
		subclass obj10 = new subclass();
		subclass obj11 = new subclass();
		subclass obj12 = new subclass();
		subclass obj13 = new subclass();

		obj5.count();
	}

}
