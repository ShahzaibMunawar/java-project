package Assignment2Q3;

public interface Resizeable {

	void resize(double z);
	
}
