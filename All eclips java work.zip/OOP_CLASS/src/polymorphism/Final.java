package polymorphism;

public class Final {

}

//not inharited
//not overrided 
//can not change the value
