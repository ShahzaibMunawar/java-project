package exception_handling;

public class circle_with_exception {
	double radius;

	circle_with_exception(double z) {
		radius = z;

	}
	public void setRadius(double newradius) throws InvalidRadiusExcepition{
		if(newradius>=0){
			radius =newradius;
		}
		
	}
}
public class extends Exception{ // here
	private double radiuss;
	
	public new 
}

