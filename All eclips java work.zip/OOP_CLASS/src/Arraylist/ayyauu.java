package Arraylist;
import java.util.
public class ayyauu {
public static void main(String[] args) {
	Arraylist<Integer> att new Arraylist<Integer>();
}
}
