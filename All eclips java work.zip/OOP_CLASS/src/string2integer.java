
public class string2integer {
public static void main(String[] args) {
	String s= "12345";
	String m="7.334";
	
	int numb1 =Integer.parseInt(s);
	double numb2 = Double.parseDouble(m);
	
	System.out.println("s="+s);
	System.out.println("m="+m);
	System.out.println("sdfgasdgasfg");
}
}
