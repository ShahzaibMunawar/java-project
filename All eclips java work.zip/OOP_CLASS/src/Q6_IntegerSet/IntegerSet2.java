package Q6_IntegerSet;

public class IntegerSet2 {
	private static final int Length = 99;
	private boolean[] a;
}
