package Abstract_class;

abstract class B extends A {
	B(int a, int b) {
		super(a);
		b = 4;
	}

	abstract void mthdc();
}
