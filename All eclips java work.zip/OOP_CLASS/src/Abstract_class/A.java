package Abstract_class;

abstract public class A {
	int ab;
	A(int a) {
		ab = 5;
	}

	abstract void mthda();
	
	abstract void mthdb();
}
