package compositionn;

public class mainClass {

	public static void main(String args[]) {
		tuna tun = new tuna(4, 5, 6);
		celebrate cell = new celebrate("Shahzaib", tun);
		System.out.println(cell);
	}

}
