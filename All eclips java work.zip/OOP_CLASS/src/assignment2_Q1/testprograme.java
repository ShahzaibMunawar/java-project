package assignment2_Q1;

public class testprograme {
	public static void main(String[] args) {
		test obj = new test();
		obj.display();
	}
}
