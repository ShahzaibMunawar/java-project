main program : StudRec.java

note: please give me credits if you will be using this program other than personal use.. ^_^ thanx.. :D
