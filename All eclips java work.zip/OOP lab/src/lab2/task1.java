package lab2;

import java.util.Scanner;

public class task1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		heater obj = new heater();
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the min value of temp");
		int m = in.nextInt();
		obj.min(m);
		System.out.println("Enter the max value of temp");
		int mm = in.nextInt();
		obj.max(mm);
		System.out.println("Enter the Increment value of temp");
		int i = in.nextInt();
		;
		if (i > 0) {
			obj.setIncrement(i);
		} else {
			System.out.println("negetive increment in not allowed");
		}
		obj.warmer();
		obj.cooler();
		obj.cooler();
		obj.setTemp();
	}

}

class heater {
	int temperature;
	int min;
	int max;
	int increment;

	heater() {
		temperature = 15;
	}

	void warmer() {
		if (temperature <= max) {
			temperature += increment;
		} else {
			System.out.println("Temperature is high then max value");
		}
	}

	void cooler() {
		if (temperature >= min) {

			temperature -= increment;

		} else {
			System.out.println("Temperature is low then minnimum value");
		}
	}

	void setTemp() {
		System.out.println("temperature = " + temperature);
	}

	void min(int mi) {
		min = mi;
	}

	void max(int mx) {
		max = mx;
	}

	void setIncrement(int inc) {
		increment = inc;
	}

}