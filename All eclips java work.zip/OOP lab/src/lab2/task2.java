package lab2;

public class task2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

time obj2=new time();
time obj=new time();

obj.member();
obj.member2();
obj.add();
	}

}
class time{
	int hours;
	int minutes;
	int seconds;
	int a,b,c,s,t,u;
	time(){
		hours=0;
		minutes=0;
		seconds=0;
	}
	void member(){
		hours=11;
		minutes=59;
		seconds=59;
		System.out.println(hours+":"+minutes+":"+seconds);
	}
	void member2(){
		a=11;
		b=59;
		c=59;
		System.out.println(a+":"+b+":"+c);
	}
void add(){
		s=hours+a;
		t=minutes+b;
		u=seconds+c;
		System.out.println(s+":"+t+":"+u);
	}

}
