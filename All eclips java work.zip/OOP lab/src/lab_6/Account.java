package lab_6;

public abstract class Account {
	double saving, total;

	abstract void credit(double s);

	abstract void debit(double d);

}

class saving_account extends Account {
	void credit(double s) {
		this.saving = s;
	}

	void debit(double d) {
		total = saving * d;
		System.out.println("saving=" + saving);
		System.out.println("Debit=" + total);
	}
}

class current_account extends Account {

	void credit(double s) {
		this.saving = s;
	}

	void debit(double d) {
		total = saving * d;
		System.out.println("saving=" + saving);
		System.out.println("Debit=" + total);
	}

}

class lab6_main {
	public static void main(String[] args) {
		Account[] object = new Account[3];
		object[0] = new saving_account();
		object[1] = new current_account();
		object[0].credit(5000);
		object[0].debit(0.5);
		object[1].credit(2000);
		object[1].debit(0.2);
	}
}