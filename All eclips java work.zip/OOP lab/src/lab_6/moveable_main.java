package lab_6;

public class moveable_main {
	public static void main(String[] args) {
		// declaring the object of interface
		moveable[] obj = new moveable[3];

		// assigning classes to interface object
		obj[0] = new moveablepoint();
		obj[1] = new MoveableCircle();
		// 1st obj
		obj[0].moveup(2);
		obj[0].movedown(3);
		obj[0].moveright(55);
		obj[0].moveleft(6);

		System.out.println("===================");

		// 2nd obj
		obj[1].movedown(6);
		obj[1].moveleft(7);
		obj[1].moveright(3);
		obj[1].moveup(2);

	}
}
