package lab_6;

public interface moveable {
	
	public void  moveup( int u);

	public void movedown(int u);

	void moveleft(int u);

	void moveright(int u);
}
