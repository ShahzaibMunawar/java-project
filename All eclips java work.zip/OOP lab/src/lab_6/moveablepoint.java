package lab_6;

public class moveablepoint implements moveable {
	public void moveup(int u) {
		System.out.println("point moved " + u + " units up!");
	}

	public void movedown(int u) {
		System.out.println("point moved " + u + " units down");
	}

	public void moveleft(int u) {
		System.out.println("point moved " + u + " units left");
	}

	public void moveright(int u) {
		System.out.println("point moved " + u + " units right");
	}
}
