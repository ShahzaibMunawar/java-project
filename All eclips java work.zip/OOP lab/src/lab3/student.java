package lab3;

public class student {
	private int RollNo;
	private String name;
	private int cgpa;

	void set_name(String n) {
		name = n;
	}

	String get_name() {
		return name;
	}

	void set_rollNo(int r) {
		RollNo = r;
	}

	int get_rollno() {
		return RollNo;
	}

}

class test {
	public static void main(String args[]) {

		student obj = new student();
		for (int i = 0; i < 50; i++) {
			
		}
	}
}
