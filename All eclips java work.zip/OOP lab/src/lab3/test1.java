package lab3;

import java.util.Scanner;

import java.util.Scanner;

public class test1 {

	public static void main(String[] args) {
		int arr[] = new int[10];
		int mod ;
		int number = 1234444;

		while (number > 0) {
			mod = number % 10;

			for (int i = 0; i < 10; i++) {
				if ( i == mod) {
					arr[i] = arr[i] + 1;
				}
			}
			number = number / 10;
		}
		for (int i = 0; i < 10; i++) {
		System.out.println( arr[i] );
		}
	}
}