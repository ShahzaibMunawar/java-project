package lab3;

public class Employee {
	static int noOfEmplyee = 0;

	Employee() {
		noOfEmplyee++;
	}

	void display() {
		noOfEmplyee++;
		System.out.println(noOfEmplyee);
	}

}
