package lab3;

import java.util.Scanner;

public class player {

	player arr[] = new player[10];
	Scanner in = new Scanner(System.in);
	int id, number;

	void input() {
		for (int i = 0; i < arr.length; i++) {
			id = in.nextInt();
			number = in.nextInt();
		}
	}
}
