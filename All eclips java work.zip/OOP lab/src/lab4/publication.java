package lab4;

import java.util.Scanner;

public class publication {
	String title;
	int price;

	publication(String t, int p) {
		title = t;
		price = p;
	}

	void get_data(String t, int p) {
		title = t;
		price = p;
	}

	void put_data() {
		System.out.println("Title = " + title);
		System.out.println("price = " + price);
	}

}

class books extends publication {
	int pagecount;

	books(String t, int p, int pc) {
		super(t, p);
		pagecount = pc;

	}

	void get_data(int p) {
		pagecount = p;

	}

	void put_data() {
		super.put_data();
		System.out.println("Pages = " + pagecount);
	}

}

class tape extends publication {
	int time;

	tape(String t, int p, int tt) {
		super(t, p);
		time = tt;
	}

	void get_data(int t) {
		time = t;
	}

	void put_data() {
		super.put_data();
		System.out.println("time = " + time);
	}
}

class finall {
	public static void main(String args[]) {
		tape ob1 = new tape("alchemist", 222, 123);
		books ob2 = new books("7 habbit", 34, 112);
		sales ob3 = new sales(123, 2234, 5555);

		ob1.put_data();
		System.out.println();
		ob2.put_data();
		System.out.println();
		ob3.put_data();
	}
}

class sales {
	double monthlysale1, monthlysale2, monthlysale3;

	sales(double a, double b, double c) {
		monthlysale1 = a;
		monthlysale2 = b;
		monthlysale3 = c;
	}

	void put_data() {
		System.out.println("1st month sale =" + monthlysale1);
		System.out.println("2st month sale =" + monthlysale2);
		System.out.println("3st month sale =" + monthlysale3);
	}
}
