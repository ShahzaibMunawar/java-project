package lab4;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

public class payment {
	double amount;

	void set_amount(double a) {
		amount = a;
	}

	double get_amount() {
		return amount;
	}

	void payment_detail() {
		System.out.println("The amount of payment is = " + amount);
	}
}

class cashpayment extends payment {

	cashpayment(double a) {
		super.set_amount(a);
	}

	void payment_detail1() {
		System.out.println("The total aount of payment = " + super.get_amount());
	}

}

class CCpayment extends cashpayment {
	String cardname;
	String expdate;
	int ccnumber;

	CCpayment(double x, String n, String e, int c) {
		super(x);
		cardname = n;
		expdate = e;
		ccnumber = c;
	}

	void payment_detail() {
		super.payment_detail1();
		System.out.println("cradit card name " + cardname);
		System.out.println("cradit card expdate " + expdate);
		System.out.println("cradit card card number " + ccnumber);
		System.out.println();

	}
}

class main {

	public static void main(String args[]) {
		CCpayment pay1 = new CCpayment(222.2, "HBl", "12/2/2020", 1234546);
		CCpayment pay2 = new CCpayment(23454, "Allied", "12/2/2020", 11222334);

		pay1.payment_detail();
		pay2.payment_detail();
	}
}
