package lab7;

public class account {
	double deposit;
	double draw;
	double amount=500;

	public void deposit(double i) {
		amount = amount + i;

	}

	public void draw(double i) {
		try{
			if (i > amount) {
				throw new Exception("Not money");
			} else {
				amount = amount - i;
			}
		}catch(Exception e){
			System.out.println("Not Enough Money");
		}
		
	}
	public void totalamount(){
		System.out.println("Total amount="+amount);
	}

}
class main{
	public static void main(String[] args) {
		account obj=new account();
		obj.draw(10000);
		obj.draw(10);
		obj.totalamount();
	}
}
