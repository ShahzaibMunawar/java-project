package lab7;

public class TooMuchSufficientException {
	String message = null;

	TooMuchSufficientException() {

	}

	TooMuchSufficientException(String s) {
		message = s;
	}
	if(message.length>0){
		return message;
	}
	else 
	{
		return "To much stuff";
	}

}
