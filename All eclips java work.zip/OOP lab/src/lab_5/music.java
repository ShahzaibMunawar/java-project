package lab_5;

public class music {

	protected String songTitle;
	protected String songName;
	protected int singingYear;

	music() {
		songTitle = "null";
		songName = "null";
		singingYear = 0000;
	}

	music(String st, String sn, int sy) {
		songTitle = st;
		songName = sn;
		singingYear = sy;
	}

	public String getSongTitle() {
		return songTitle;
	}

	public void setSongTitle(String songTitle) {
		this.songTitle = songTitle;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public int getSingingYear() {
		return singingYear;
	}

	public void setSingingYear(int singingYear) {
		this.singingYear = singingYear;
	}
}

class Folkmusic extends music {
	String provinceName;

	Folkmusic(String st, String sn, int sy, String pn) {
		super(st, sn, sy);
		provinceName = pn;
	}

	Folkmusic() {
		provinceName = "null";
	}

	void setProvinceName(String nn) {
		provinceName = nn;
	}

	void show() {
		System.out.println("Song Title=" + super.songTitle);
		System.out.println("Song year= " + super.singingYear);
		System.out.println("Song Name = " + super.songName);
		System.out.println("Song province= " + provinceName);
	}
}

class lab5_2main {
	public static void main(String[] args) {
		Folkmusic music = new Folkmusic("Babli badmash hy", "BBH", 2012, "Dehli");
		music.setProvinceName("gujjrat");
		music.show();

	}
}
