package lab_5;

public class notebook {
	protected int manufacID;

	protected String ManufacName;

	notebook(int mi, String mn) {
		manufacID = mi;
		ManufacName = mn;
	}

	// getters and seters

	public int getManufacID() {
		return manufacID;
	}

	public String getManufacName() {
		return ManufacName;
	}

	public void setManufacName(String manufacName) {
		this.ManufacName = manufacName;
	}

	public void setManufacID(int manufacID) {
		this.manufacID = manufacID;
	}

}

// class Enotebook

class Enotebook extends notebook {
	protected int size;

	Enotebook(int smi, String smn) {
		super(smi, smn);
	}

	public void setsize(int sz) {
		size = sz;
	}

	void display() {
		System.out.println("Manufacture ID = +" + super.manufacID);
		System.out.println("Manufacture Name = " + super.ManufacName);
		System.out.println("Size of NoteBook =" + size);
	}
}// end class

// class

class PaperNotebook extends notebook {
	protected int totalPage;

	PaperNotebook(int smi, String smn) {
		super(smi, smn);
	}

	public void setpage(int page) {
		totalPage = page;
	}

	void display() {
		System.out.println("Manufacture ID = +" + super.manufacID);
		System.out.println("Manufacture Name = " + super.ManufacName);
		System.out.println("Total pages of NoteBook =" + totalPage);
	}
}

class lab5_1_main {
	public static void main(String[] args) {
		Enotebook note = new Enotebook(12786, "Holy Quran");
		note.setsize(59);
		note.display();
		System.out.println("/n/n");
		PaperNotebook paper = new PaperNotebook(556678, "Al chemist");
		paper.setpage(564);
		paper.display();
	}
}
