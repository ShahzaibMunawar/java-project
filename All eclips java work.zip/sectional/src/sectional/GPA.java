package sectional;

public class GPA {
	String subjects;
	double CHR;
	double gradepoints;
	private static double hiGPA;
	double weight;


	void set_sub(String sub) {
		subjects = sub;
	}

	void set_CHR(double chr) {
		CHR =CHR+chr;
	}

	void set_GP(double gp) {
		gradepoints = gp;
	}


	double WS() {
		weight = gradepoints * CHR;
		return weight;
	}

	double gGPA() {
		hiGPA = weight / CHR;
		return hiGPA;
	}

}
