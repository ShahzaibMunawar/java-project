package sectional;

import java.util.Scanner;

public class test {
public static void main(String[] args) {
	GPA obj=new GPA();
	

	obj.set_sub("OOP");
	obj.set_CHR(4.0);
	obj.set_GP(3.5);
	obj.set_sub("ICP");
	obj.set_CHR(4.0);
	obj.set_GP(4.0);
	
	
	

	System.out.println(obj.CHR);
	System.out.println(obj.gradepoints);
	System.out.println("Weights Score ="+obj.WS());
	System.out.println("HI GPA="+obj.gGPA());
}
}
